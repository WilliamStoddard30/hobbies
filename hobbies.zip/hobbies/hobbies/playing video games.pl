playing video games
going to game night over at my parents
hanging out with my friend